const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

export async function getAccountByPassword(accountPassword) {
    return new Promise((resolve, reject) => {
      db.get(`SELECT * FROM account WHERE accountPassword='${accountPassword}'`, (err, row) => {
        if (err) {
          reject(err);
        } else if (!row) {
          reject(new Error(`Account with accountPassword ${accountPassword} not found.`));
        } else {
          resolve(row);
        }
      });
    });
  }

export async function getRemainingTokensByPassword(accountPassword) {
    return new Promise((resolve, reject) => {
      db.get(`SELECT totalTokens, usedTokens FROM account WHERE accountPassword='${accountPassword}'`, (err, row) => {
        if (err) {
          reject(err);
        } else if (!row) {
          reject(new Error(`Account with accountPassword ${accountPassword} not found.`));
        } else {
          const remainingTokens = row.totalTokens - row.usedTokens;
          resolve({ remainingTokens });
        }
      });
    });
  }

export async function accountExists(accountPassword) {
    return new Promise((resolve, reject) => {
        // 获取Key对应的用户，并判断是否存在
        db.get(`SELECT * FROM account WHERE accountPassword='${accountPassword}'`, (err, row) => {
            if (err) {
                reject(err);
            } else if (!row) {
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
  }

// 根据password修改用户已经使用的token数量，变成原来的加上usedTokens
export async function updateUsedTokensByPassword(accountPassword, usedTokens) {
    return new Promise((resolve, reject) => {
      db.run(`UPDATE account SET usedTokens = usedTokens + ${usedTokens} WHERE accountPassword='${accountPassword}'`, (err) => {
        if (err) {
          reject(err);
        } else {
          resolve(true);
        }
      });
    });
  }