export function createTable() {
  const sqlite3 = require('sqlite3').verbose();

  const db = new sqlite3.Database('./database.db');

  db.serialize(() => {
    db.run(`
      CREATE TABLE IF NOT EXISTS account (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        accountName TEXT NOT NULL,
        accountPassword TEXT UNIQUE NOT NULL,
        totalTokens INTEGER NOT NULL,
        usedTokens INTEGER NOT NULL,
        regDate TEXT NOT NULL
      );
    `);
  });

  db.close();
}