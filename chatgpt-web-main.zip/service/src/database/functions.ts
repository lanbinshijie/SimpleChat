import mysql from 'mysql';

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'icbcbcbcb',
  password: 'icbcbcbcb',
  database: 'icb'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL database:', err);
    return;
  }
  console.log('Connected to MySQL database as id', connection.threadId);
});

export async function getAccountByPassword(accountPassword) {
  console.log('Getting account by password...');
  return new Promise((resolve, reject) => {
    connection.query(`SELECT * FROM account WHERE accountPassword='${accountPassword}'`, (error, results, fields) => {
      if (error) {
        console.log('Error getting account by password:', error);
        reject(error);
      } else if (results.length === 0) {
        console.log(`Account with accountPassword ${accountPassword} not found.`);
        reject(new Error(`Account with accountPassword ${accountPassword} not found.`));
      } else {
        console.log('Account found:', results[0]);
        resolve(results[0]);
      }
    });
  });
}

export async function getRemainingTokensByPassword(accountPassword) {
  console.log('Getting remaining tokens by password...');
  return new Promise((resolve, reject) => {
    connection.query(`SELECT totalTokens, usedTokens FROM account WHERE accountPassword='${accountPassword}'`, (error, results, fields) => {
      if (error) {
        console.log('Error getting remaining tokens by password:', error);
        reject(error);
      } else if (results.length === 0) {
        console.log(`Account with accountPassword ${accountPassword} not found.`);
        reject(new Error(`Account with accountPassword ${accountPassword} not found.`));
      } else {
        console.log('Remaining tokens found:', results[0].totalTokens - results[0].usedTokens);
        const remainingTokens = results[0].totalTokens - results[0].usedTokens;
        resolve({ remainingTokens });
      }
    });
  });
}

export async function accountExists(accountPassword) {
  console.log('Checking if account exists...');
  return new Promise((resolve, reject) => {
    connection.query(`SELECT COUNT(*) AS count FROM account WHERE accountPassword='${accountPassword}'`, (error, results, fields) => {
      if (error) {
        console.log('Error checking if account exists:', error);
        reject(error);
      } else {
        console.log('Account exists:', results[0].count > 0);
        resolve(results[0].count > 0);
      }
    });
  });
}

export async function updateUsedTokensByPassword(accountPassword, usedTokens) {
  return new Promise((resolve, reject) => {
    connection.query(`UPDATE account SET usedTokens = usedTokens + ${usedTokens} WHERE accountPassword='${accountPassword}'`, (error, results, fields) => {
      if (error) {
        reject(error);
      } else {
        resolve(true);
      }
    });
  });
}
