import mysql from 'mysql';

export function createTable() {
  const connection = mysql.createConnection({
    host: 'localhost',
    user: 'icbcbcbcb',
    password: 'icbcbcbcb',
    database: 'icb'
  });

  connection.connect((err) => {
    if (err) {
      console.error('Error connecting to MySQL database:', err);
      return;
    }
    console.log('Connected to MySQL database as id', connection.threadId);

    connection.query(`
      CREATE TABLE IF NOT EXISTS account (
        id INT AUTO_INCREMENT PRIMARY KEY,
        accountName VARCHAR(255) NOT NULL,
        accountPassword VARCHAR(255) UNIQUE NOT NULL,
        totalTokens INT NOT NULL,
        usedTokens INT NOT NULL,
        regDate DATE NOT NULL
      );
    `, (error, results, fields) => {
      if (error) throw error;

      console.log('Table "account" created successfully');
    });

    connection.end((err) => {
      if (err) {
        console.error('Error disconnecting from MySQL database:', err);
        return;
      }
      console.log('Disconnected from MySQL database');
    });
  });
}
